#! /bin/bash
# major
# Lit un fichier de notes Prénom/Nom/Note sur l'entrée standard et
# affiche sur la sortie standard le prénom et le nom d'un élève ayant
# eu la meilleure note.

# "Algorithme" utilisé:
# 1. On trie les données par ordre croissant selon les notes
# 2. On sélectionne la dernière ligne
# 3. On sélectionne le nom et le prénom
# 4. On remplace le slash par une espace

# On peut faire 3 et 4 avec un seul appel à 'cut'
sort -t'/' -k3 -n | tail -n1 | cut -d'/' --output-delimiter ' ' -f1,2

# Une autre solution avec une commande par étape
# sort -t'/' -k3 -n | tail -n1 | cut -d'/' -f1,2 | tr '/' ' '
