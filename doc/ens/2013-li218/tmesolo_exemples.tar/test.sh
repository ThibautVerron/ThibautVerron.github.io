#!/bin/bash

dossier=$1
scripts="moyenne.sh toutesMoyennes.sh petitsGroupes.sh moinsRemplie.sh optimisation.sh optimisationDetaillee.sh verification.sh"
exemplesdir="/Infos/lmd/2013/licence/ue/li218-2013oct/tmesolo/Groupe4/"
outdir="${exemplesdir}/Out/"

tmp=$(mktemp)

retour=0

for script in $scripts
do
    nom=$(basename $script ".sh")
    pathscript="${dossier}${script}"
    if [ ! -e "$pathscript" ]
    then
	echo "Script ${script} non trouvé."
    else
	if bash -n $pathscript
	then
	    for exemple in $(ls ${exemplesdir})
	    do
		result="${exemple}_${nom}.out"
		pathresult="${outdir}${result}"
		#echo $pathresult >&2
		if [ -e "${pathresult}" ]
		then
		    argsfile="$outdir${exemple}_${nom}.args"
		    if [ -e "${argsfile}" ]
		    then
			args=$(cat $argsfile | tr '\n' ' ')
		    else
			args=''
		    fi
		    pathexemple="${exemplesdir}${exemple}"
		    # echo ${pathexemple} >&2
		    # echo $args >&2
		    ${pathscript} ${args} ${pathexemple} > ${tmp}
		    # cat $tmp >&2
		    # cat $pathresult >&2
		    if diff -qb $tmp $pathresult > /dev/null
		    then
			echo "$script : exemple $exemple : OK"
		    else
			echo "$script : exemple $exemple : ERREUR"
			echo "Résultat attendu:"
			cat $pathresult
			echo "Résultat retourné:"
			cat $tmp
			retour=1
		    fi
		# else
		#     echo "Pas de fichier à comparer $pathresult" >&2
		fi
	    done
	else
	    echo "${script} : erreur de syntaxe."
	    retour=1
	fi
    fi
done

rm $tmp

exit $retour
