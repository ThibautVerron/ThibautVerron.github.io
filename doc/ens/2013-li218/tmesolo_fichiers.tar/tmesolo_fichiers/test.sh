#!/bin/bash

dossier=$1
scripts="moyenne.sh toutesMoyennes.sh petitsGroupes.sh moinsRemplie.sh optimisation.sh optimisationDetaillee.sh verification.sh"
exemplesdir="/Infos/lmd/2013/licence/ue/li218-2013oct/TME_solo4"
outdir="${exemplesdir}/Out"

tmp=$(mktemp)

retour=0

for script in $scripts
do
    nom=$(basename $script ".sh")
    if [ ! -e "${dossier}/${script}" ]
    then
	echo "Script ${script} non trouvé."
    else
	if bash -n $script
	then
	    for exemple in ${exemplesdir}/*
	    do
		result="${exemple}_${nom}.out"
		if [ -e "${outdir}/${result}" ]
		then
		    argsfile="${exemple}_${nom}.args"
		    if [ -e "${outdir}/${argsfile}" ]
		    then
			args=$(cat argsfile | tr '\' ' ')
		    else
			args=''
		    fi
		    ${dossier}/${script} ${args} ${exemple} > ${tmp}
		    if diff -q $tmp $result > /dev/null
		    then
			echo "$script : exemple $exemple : OK"
		    else
			echo "$script : exemple $exemple : ERREUR"
			retour=1
		    fi
		fi
	    done
	else
	    echo "${script} : erreur de syntaxe."
	    retour=1
	fi
    fi
done

rm $tmp

exit $retour
