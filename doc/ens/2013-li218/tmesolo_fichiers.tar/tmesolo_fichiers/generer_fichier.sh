#!/bin/bash

fichier=$1
formations=$2
maxue=$3
maxgp=$4

limdown=8
limup=40

for form in $formations
do
    nbue=$(((RANDOM % maxue) +10))
    for i in $(seq 10 $nbue)
    do
	code="${form}$i"
	ligne=""
	nbgp=$(((RANDOM % maxgp) +1))
	sum=0
	for j in $(seq 1 $nbgp)
	do
	    nbetu=$(((RANDOM % (limup - limdown) + limdown)))
	    sum=$((sum+nbetu))
	    ligne="${ligne};${nbetu}"
	done
	ligne="${code};${sum};${nbgp}${ligne}"
	echo $ligne
    done
done > $fichier

