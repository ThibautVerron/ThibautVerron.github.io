#!/bin/bash

grep -E 'ˆ[0-9]{1,4} [A-Z]{1,3} (1[6-9]|2[0-9]|3[0-3])\
 (marron|noire|bleu marine|(gris|vert) foncé$'
