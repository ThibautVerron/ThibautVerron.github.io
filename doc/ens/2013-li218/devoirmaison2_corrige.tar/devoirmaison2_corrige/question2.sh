#!/bin/bash

grep -E 'ˆ[1-9]([0-9]){0,3} [[:upper:]]{1,3}\
 ([02][1-9]|[13-8][0-9]|9[1-5]|2[AB]|97[1-8])\
 (marron|noire|bleu marine|(gris|vert) foncé$'
