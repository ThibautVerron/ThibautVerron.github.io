#!/bin/bash

grep -E 'ˆ1[0-9]{2,3} [OPQRD][A-Z]{2} 91\
 (marron|noire|bleu marine|(gris|vert) foncé$

