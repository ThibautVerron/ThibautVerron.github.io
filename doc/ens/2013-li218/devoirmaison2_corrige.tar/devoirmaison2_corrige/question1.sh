#!/bin/bash

grep -E 'ˆ[A-Z]{2}-[0-9]{3}-[0-9]{2}\
 (marron|noire|bleu marine|(gris|vert) foncé$'



