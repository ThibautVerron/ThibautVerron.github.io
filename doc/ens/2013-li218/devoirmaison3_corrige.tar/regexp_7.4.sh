#!/bin/bash

# who renvoie tous les logins des utilisateurs connectés, ainsi que
# d'autres informations. On récupère les logins comme première
# information de chaque ligne.

who | sed -nr "s/^([[:alnum:]]+).*/\1/p"
