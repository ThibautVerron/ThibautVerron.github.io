#!/bin/bash

# C'était un exercice de la feuille "premiers scripts". On voit ici
# comment un seul sed peut remplacer une composition de grep suivi de
# cut.

/sbin/ifconfig eth0 | sed -nr "s/.*inet adr:([^ ]*) .*/\1/p"
