#!/bin/bash

# Il n'est pas rentable de rappeler moyenne.sh, car le grep ferait
# parcourir le fichier pour chaque ligne. À la place, on réutilise le
# code "étant donné la ligne précédent", et on remplace le grep par
# une boucle de parcours du fichier.

fichier=$1

while read ligne
do
    code=$(cut -d';' -f1 <<< $ligne)
    nbtotal=$(cut -d';' -f2 <<< $ligne)
    nbgroupes=$(cut -d';' -f3 <<< $ligne)
    res=$((${nbtotal}/${nbgroupes}))
    echo "${code};${res}"
done < $fichier
