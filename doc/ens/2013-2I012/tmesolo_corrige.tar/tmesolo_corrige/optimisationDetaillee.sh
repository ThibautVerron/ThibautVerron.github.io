#!/bin/bash

# Même commentaire que pour optimisation.sh

fichier=$1
limup=32

while read ligne
do
    code=$(cut -d';' -f1 <<< $ligne)
    nbtotal=$(cut -d';' -f2 <<< $ligne)
    nbgroupes=$(cut -d';' -f3 <<< $ligne)
    if [ "$((nbtotal/nbgroupes))" -gt "$limup" ]
    then
	miss=$(((nbtotal-1)/limup - nbgroupes +1))
	echo "${code}: pas assez de groupes ($miss)"
    elif [ "$((32*(nbgroupes-1)))" -ge "$nbtotal" ]
    then
	rab=$(((32*(nbgroupes-1) - nbtotal)/32+1))
	echo "${code}: trop de groupes ($rab)"
    fi
done < $fichier
