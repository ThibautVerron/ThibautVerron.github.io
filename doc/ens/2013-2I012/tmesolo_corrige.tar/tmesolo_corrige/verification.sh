#!/bin/bash

# On utilise cette fois-ci set pour lire les effectifs des groupes. Cette méthode offre l'avantage de permettre facilement de compter les groupes, via la variable $#

fichier=$1
retour=0

while read ligne
do
    code=$(cut -d';' -f1 <<< $ligne)
    nbtotal=$(cut -d';' -f2 <<< $ligne)
    nbgroupes=$(cut -d';' -f3 <<< $ligne)
    effectifs=$(cut -d';' -f4- --output-delimiter=' ' <<< $ligne)
    set $effectifs
    if [ "$#" -ne "$nbgroupes" ]
    then
	echo "$code: $nbgroupes groupes annoncés, mais $# effectifs donnés"
	retour=1
    else
	sum=0
	for n in $@
	do
	    sum=$((sum+n))
	done
	if [ "$sum" -ne "$nbtotal" ]
	then
	    echo "$code: $nbtotal élèves annoncés, mais la somme des effectifs des groupes vaut $sum"
	    retour=1
	fi
    fi
done < $fichier

exit $retour
