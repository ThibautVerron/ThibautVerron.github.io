#!/bin/bash

# C'était le premier script qui vous demandait vraiment de parcourir les effectifs des groupes. Vous aviez une solution avec set (un exemple est donné dans verification.sh). Ce que beaucoup ont fait, utiliser une boucle for avec un compteurn et cut -f$i, marchait aussi.
#
# Je propose ici une solution qui me semble plus naturelle si on ne veut que parcourir la liste : un cut pour récupérer tous les champs après le 4e séparés par des espaces, et ensuite un parcours de liste.

fichier=$1
limite=10

while read ligne
do
    trouve=''
    effectifs=$(cut -d';' -f4- --output-delimiter=' ' <<< $ligne)
    for n in $effectifs
    do
	if [ "$n" -le "$limite" ]
	then
	    trouve='oui'
	    break
	fi
    done
    if [ ! -z "$trouve" ]
    then
	code=$(cut -d';' -f1 <<< $ligne)
	echo $code
    fi
done < $fichier
