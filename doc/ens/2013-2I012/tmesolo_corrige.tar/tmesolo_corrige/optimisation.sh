#!/bin/bash

# Encore du parcours de lignes avec des opérations arithmétiques sur les champs, rien de plus compliqué que toutesMoyennes.sh

fichier=$1
limup=32

while read ligne
do
    code=$(cut -d';' -f1 <<< $ligne)
    nbtotal=$(cut -d';' -f2 <<< $ligne)
    nbgroupes=$(cut -d';' -f3 <<< $ligne)
    if [ "$((nbtotal/nbgroupes))" -gt "$limup" ]
    then
	echo "${code}: pas assez de groupes"
    elif [ "$((32*(nbgroupes-1)))" -ge "$nbtotal" ]
    then
	echo "${code}: trop de groupes"
    fi
done < $fichier
