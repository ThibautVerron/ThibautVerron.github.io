#!/bin/bash

# Le script qui suit propose une solution avec les outils à votre
# disposition, l'utilisation de fonctions et de tableaux permettrait
# de rendre ce code un peu plus naturel.  Un appel à des expressions
# régulières aurait aussi déjà amélioré un peu les choses.
#
# L'algorithme proposé est le suivant :
# - on trie le fichier selon le premier champ, par ordre alphabétique (de sorte que les UE d'une même formation sont groupées)
# - puis on lit, formation par formation, pour trouver le minimum

fichier=$1
limite=$10

tmp=$(mktemp)

cat $fichier | sort -k1 > $tmp

formationmax=''
formationcurr=''
petitsgroupesmax=0
petitsgroupescurr=0

while read ligne
do
    nouvligne="${ligne:0:3};${ligne:6}"
    formation=$(cut -d';' -f1 <<< $nouvligne)
    effectifs=$(cut -d';' -f4- --output-delimiter=' ' <<< $nouvligne)
    if [ "@$formation" != "@$formationcurr" ]
    then
	if [ "$petitsgroupescurr" -gt "$petitsgroupesmax" ]
	then
	    formationmax=$formationcurr
	    petitsgroupesmax=$petitsgroupescurr
	fi
	formationcurr=$formation
	petitsgroupescurr=0
    fi
    for n in $effectifs
    do
	if [ "$n" -le "$limite" ]
	then
	    petitsgroupescurr=$((petitsgroupescurr +1))
	fi
    done
done < $tmp

# On vérifie que la dernière formation n'était pas la bonne
if [ "$petitsgroupescurr" -gt "$petitsgroupesmax" ]
then
    formationmax=$formationcurr
    petitsgroupesmax=$petitsgroupescurr
fi

echo $formationmax
rm $tmp
