#!/bin/bash

# On récupère la ligne correspondant à l'UE demandée avec grep, puis
# le nombre d'élèves et de groupes de cette UE avec cut, et enfin on
# calcule la moyenne

code=$1
fichier=$2

ligne=$(grep $1 $2)
nbtotal=$(cut -d';' -f2 <<< $ligne)
nbgroupes=$(cut -d';' -f3 <<< $ligne)

res=$((${nbtotal}/${nbgroupes}))
echo $res
